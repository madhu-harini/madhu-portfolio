# Madhu Harini Maanthi — Portfolio

A simple, responsive portfolio website.

## Run locally
Open `index.html` in a browser.

## Deploy
This single-file site can be deployed directly to:
- Vercel
- Netlify
- GitHub Pages

No build step is required.
